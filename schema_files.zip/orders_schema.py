import pandera as pa
from pandera import Column, DataFrameSchema

orders_schema = DataFrameSchema({
    "order_id": Column(str),
    "customer_id": Column(str),
    "product_id": Column(str),
    "order_date": Column(pa.DateTime),
    "quantity": Column(int, pa.Check.ge(1)),
    "total_price": Column(float, pa.Check.ge(0.0)),
    "payment_method": Column(str),
    "order_status": Column(str)
})
