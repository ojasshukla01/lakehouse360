import pandera as pa
from pandera import Column, DataFrameSchema

inventory_schema = DataFrameSchema({
    "product_id": Column(str),
    "stock_quantity": Column(int, pa.Check.ge(0)),
    "last_restock_date": Column(pa.DateTime, nullable=True)
})
