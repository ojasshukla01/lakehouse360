import pandera as pa
from pandera import Column, DataFrameSchema

employees_schema = DataFrameSchema({
    "employee_id": Column(str),
    "first_name": Column(str),
    "last_name": Column(str),
    "email": Column(str),
    "position": Column(str),
    "hire_date": Column(pa.DateTime),
    "store_assigned": Column(str)
})
