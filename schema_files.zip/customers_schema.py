import pandera as pa
from pandera import Column, DataFrameSchema, Check

customers_schema = DataFrameSchema({
    "customer_id": Column(str),
    "first_name": Column(str),
    "last_name": Column(str),
    "email": Column(str, Check.str_matches(r".+@.+\..+")),
    "phone_number": Column(str, nullable=True),
    "date_of_birth": Column(pa.DateTime, nullable=True),
    "gender": Column(str, Check.isin(["Male", "Female", "Other"]), nullable=True),
    "address": Column(str, nullable=True),
    "city": Column(str),
    "state": Column(str),
    "postcode": Column(str),
    "country": Column(str),
    "signup_date": Column(pa.DateTime),
    "loyalty_score": Column(float, Check.ge(0), nullable=True),
    "preferred_store": Column(str, nullable=True),
    "is_active": Column(bool)
})
