import pandera as pa
from pandera import Column, DataFrameSchema

feedback_schema = DataFrameSchema({
    "supplier_id": Column(str),
    "feedback_score": Column(int, pa.Check.isin([1, 2, 3, 4, 5])),
    "feedback_text": Column(str, nullable=True),
    "submitted_at": Column(pa.DateTime)
})
