import pandera as pa
from pandera import Column, DataFrameSchema

products_schema = DataFrameSchema({
    "product_id": Column(str),
    "product_name": Column(str),
    "category": Column(str),
    "price": Column(float, pa.Check.ge(0.0)),
    "supplier_id": Column(str),
    "created_at": Column(pa.DateTime)
})
