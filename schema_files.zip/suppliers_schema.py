import pandera as pa
from pandera import Column, DataFrameSchema

suppliers_schema = DataFrameSchema({
    "supplier_id": Column(str),
    "supplier_name": Column(str),
    "supplier_email": Column(str),
    "contact_number": Column(str, nullable=True),
    "location": Column(str, nullable=True)
})
