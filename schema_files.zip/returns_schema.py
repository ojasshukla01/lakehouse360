import pandera as pa
from pandera import Column, DataFrameSchema

returns_schema = DataFrameSchema({
    "return_id": Column(str),
    "order_id": Column(str),
    "product_id": Column(str),
    "return_date": Column(pa.DateTime),
    "return_reason": Column(str)
})
