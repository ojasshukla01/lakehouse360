import pandera as pa
from pandera import Column, DataFrameSchema

deliveries_schema = DataFrameSchema({
    "delivery_id": Column(str),
    "order_id": Column(str),
    "delivered_at": Column(pa.DateTime, nullable=True),
    "delivery_status": Column(str),
    "estimated_arrival": Column(pa.DateTime)
})
